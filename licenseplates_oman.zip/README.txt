🇴🇲 Oman License Plate Mod by Scoroo
Discord: scoroo#5113

This mod adds three authentic Omani license plate types to BeamNG.drive:

- [oman] Private License Plate – White background for civilian vehicles
- [oman] Red License Plate – Red background for commercial vehicles
- [oman] Black License Plate – Black background for race cars (not allowed on public roads)

Format: Two English letters followed by five digits (e.g. MU45678)
Arabic digits are rendered using the Bold Naskh font.

How to Use:
1. Place the mod .zip in your BeamNG/mods folder
2. Activate it in the Mod Manager
3. Select your plate type in Vehicle Config > License Plate Design

Compatible with EU and US plate formats. Future updates may include dynamic JSON logic for automatic plate assignment.